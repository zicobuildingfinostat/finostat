"""
Finostat news wire
==================

Pulls financial and geopolitical headlines from two sources and merges them:

  1. X (Twitter) API v2 — recent search over a curated list of accounts.
     Needs X_BEARER_TOKEN in the environment. X bills per post read
     ($0.005/post in 2026), so we poll with `since_id` and only pay for
     posts we have not seen yet.

  2. RSS feeds — free, no keys. Used as a fallback and as a supplement.

Both feed into one in-memory store. A background thread refreshes on a
timer, and `subscribe()` lets the Flask SSE endpoint push new items to
browsers the moment they arrive.
"""

from __future__ import annotations

import html
import json
import logging
import os
import queue
import re
import threading
import time
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
from typing import Iterable

import requests

log = logging.getLogger("finostat.news")

# ---------------------------------------------------------------------------
# Configuration — tweak these, or set the env vars
# ---------------------------------------------------------------------------

X_BEARER_TOKEN = os.environ.get("X_BEARER_TOKEN", "").strip()
X_POLL_SECONDS = int(os.environ.get("X_POLL_SECONDS", "300"))      # 5 min
RSS_POLL_SECONDS = int(os.environ.get("RSS_POLL_SECONDS", "180"))  # 3 min
MAX_ITEMS = 120

# Accounts polled on X. Keys are handles, values are the category tag.
# Keep this list short: every post returned costs money.
X_ACCOUNTS: dict[str, str] = {
    # financial
    "Reuters": "FIN",
    "business": "FIN",        # Bloomberg
    "FirstSquawk": "FIN",
    "DeItaone": "FIN",
    "NSEIndia": "FIN",
    "ETMarkets": "FIN",
    "moneycontrolcom": "FIN",
    "RBI": "FIN",
    # geopolitical
    "ReutersWorld": "GEO",
    "BBCBreaking": "GEO",
    "AJENews": "GEO",
    "SpectatorIndex": "GEO",
}

# Free RSS feeds. (url, source label, category)
RSS_FEEDS: list[tuple[str, str, str]] = [
    ("https://economictimes.indiatimes.com/markets/rssfeeds/1977021501.cms", "ET Markets", "FIN"),
    ("https://www.moneycontrol.com/rss/latestnews.xml", "Moneycontrol", "FIN"),
    ("https://www.livemint.com/rss/markets", "Mint", "FIN"),
    ("https://feeds.bbci.co.uk/news/world/rss.xml", "BBC World", "GEO"),
    ("https://www.aljazeera.com/xml/rss/all.xml", "Al Jazeera", "GEO"),
    ("https://rss.nytimes.com/services/xml/rss/nyt/World.xml", "NYT World", "GEO"),
]

# Keywords that upgrade an item to "BREAKING" styling on the front end.
HOT_WORDS = re.compile(
    r"\b(breaking|rbi|rate (hike|cut)|fed|fomc|sebi|circuit|crash|war|strike|"
    r"sanction|ceasefire|missile|opec|crude|budget|gst|tariff)\b",
    re.I,
)


# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------

@dataclass
class NewsItem:
    id: str
    source: str        # display name, e.g. "Reuters"
    handle: str        # "@Reuters" or feed label
    text: str
    url: str
    category: str      # "FIN" | "GEO"
    ts: float          # unix seconds
    hot: bool = False
    via: str = "rss"   # "x" | "rss"

    def to_dict(self) -> dict:
        d = asdict(self)
        d["time"] = datetime.fromtimestamp(self.ts, tz=timezone.utc).isoformat()
        return d


class NewsStore:
    """Thread-safe ring buffer of items plus subscriber queues for SSE."""

    def __init__(self, max_items: int = MAX_ITEMS):
        self._items: dict[str, NewsItem] = {}
        self._max = max_items
        self._lock = threading.Lock()
        self._subs: set[queue.Queue] = set()

    def add(self, items: Iterable[NewsItem]) -> list[NewsItem]:
        fresh: list[NewsItem] = []
        with self._lock:
            for it in items:
                if it.id in self._items:
                    continue
                self._items[it.id] = it
                fresh.append(it)
            if len(self._items) > self._max:
                keep = sorted(self._items.values(), key=lambda x: x.ts, reverse=True)[: self._max]
                self._items = {k.id: k for k in keep}
        if fresh:
            fresh.sort(key=lambda x: x.ts)
            payload = json.dumps([f.to_dict() for f in fresh])
            for q in list(self._subs):
                try:
                    q.put_nowait(payload)
                except queue.Full:
                    pass
        return fresh

    def latest(self, category: str | None = None, limit: int = 40) -> list[dict]:
        with self._lock:
            items = list(self._items.values())
        if category in ("FIN", "GEO"):
            items = [i for i in items if i.category == category]
        items.sort(key=lambda x: x.ts, reverse=True)
        return [i.to_dict() for i in items[:limit]]

    def subscribe(self) -> queue.Queue:
        q: queue.Queue = queue.Queue(maxsize=50)
        self._subs.add(q)
        return q

    def unsubscribe(self, q: queue.Queue) -> None:
        self._subs.discard(q)


store = NewsStore()


# ---------------------------------------------------------------------------
# Source 1: X API v2 recent search
# ---------------------------------------------------------------------------

_x_since_id: str | None = None
_X_URL = "https://api.x.com/2/tweets/search/recent"


def _x_query() -> str:
    froms = " OR ".join(f"from:{h}" for h in X_ACCOUNTS)
    # exclude retweets and replies so we only pay for original headlines
    return f"({froms}) -is:retweet -is:reply"


def fetch_x() -> list[NewsItem]:
    """One poll of X. Returns new items only (uses since_id)."""
    global _x_since_id
    if not X_BEARER_TOKEN:
        return []

    params = {
        "query": _x_query(),
        "max_results": 50,
        "tweet.fields": "created_at,entities,author_id",
        "expansions": "author_id",
        "user.fields": "name,username",
    }
    if _x_since_id:
        params["since_id"] = _x_since_id

    r = requests.get(
        _X_URL,
        headers={"Authorization": f"Bearer {X_BEARER_TOKEN}"},
        params=params,
        timeout=15,
    )
    if r.status_code == 429:
        log.warning("X rate limit hit; backing off")
        return []
    r.raise_for_status()
    data = r.json()

    users = {u["id"]: u for u in data.get("includes", {}).get("users", [])}
    items: list[NewsItem] = []
    for t in data.get("data", []):
        u = users.get(t["author_id"], {})
        handle = u.get("username", "")
        text = html.unescape(t["text"])
        # swap t.co links for the expanded URL so headlines read cleanly
        for ent in t.get("entities", {}).get("urls", []):
            text = text.replace(ent["url"], ent.get("expanded_url", ent["url"]))
        text = re.sub(r"https?://\S+", "", text).strip()
        ts = datetime.fromisoformat(t["created_at"].replace("Z", "+00:00")).timestamp()
        items.append(
            NewsItem(
                id=f"x:{t['id']}",
                source=u.get("name", handle),
                handle=f"@{handle}",
                text=text,
                url=f"https://x.com/{handle}/status/{t['id']}",
                category=X_ACCOUNTS.get(handle, "FIN"),
                ts=ts,
                hot=bool(HOT_WORDS.search(text)),
                via="x",
            )
        )

    newest = data.get("meta", {}).get("newest_id")
    if newest:
        _x_since_id = newest
    return items


# ---------------------------------------------------------------------------
# Source 2: RSS (no key needed)
# ---------------------------------------------------------------------------

def fetch_rss() -> list[NewsItem]:
    try:
        import feedparser  # lazy import so the app runs without it
    except ImportError:
        log.warning("feedparser not installed; RSS disabled")
        return []

    items: list[NewsItem] = []
    for url, label, cat in RSS_FEEDS:
        try:
            feed = feedparser.parse(url)
        except Exception as exc:  # network hiccups shouldn't kill the loop
            log.warning("RSS %s failed: %s", label, exc)
            continue
        for e in feed.entries[:15]:
            link = e.get("link", "")
            title = html.unescape(e.get("title", "")).strip()
            if not title or not link:
                continue
            ts = time.time()
            if e.get("published"):
                try:
                    ts = parsedate_to_datetime(e["published"]).timestamp()
                except (TypeError, ValueError):
                    pass
            elif e.get("published_parsed"):
                ts = time.mktime(e["published_parsed"])
            items.append(
                NewsItem(
                    id=f"rss:{link}",
                    source=label,
                    handle=label,
                    text=title,
                    url=link,
                    category=cat,
                    ts=ts,
                    hot=bool(HOT_WORDS.search(title)),
                    via="rss",
                )
            )
    return items


# ---------------------------------------------------------------------------
# Background refresh loop
# ---------------------------------------------------------------------------

_started = False


def _loop() -> None:
    next_x = 0.0
    next_rss = 0.0
    while True:
        now = time.time()
        if now >= next_rss:
            try:
                store.add(fetch_rss())
            except Exception as exc:
                log.warning("RSS refresh failed: %s", exc)
            next_rss = now + RSS_POLL_SECONDS
        if X_BEARER_TOKEN and now >= next_x:
            try:
                store.add(fetch_x())
            except Exception as exc:
                log.warning("X refresh failed: %s", exc)
            next_x = now + X_POLL_SECONDS
        time.sleep(5)


def start_background() -> None:
    """Start the poller once (safe to call multiple times)."""
    global _started
    if _started:
        return
    _started = True
    threading.Thread(target=_loop, name="news-poller", daemon=True).start()
    log.info("news poller started (X=%s, RSS=%d feeds)", bool(X_BEARER_TOKEN), len(RSS_FEEDS))


def seed_sample() -> None:
    """Put a few placeholder items in the store so the UI is never empty."""
    if store.latest(limit=1):
        return
    now = time.time()
    samples = [
        ("FIN", "Finostat", "Connect X_BEARER_TOKEN or wait for RSS to load live headlines.", False),
        ("GEO", "Finostat", "Geopolitical wire will appear here as feeds refresh.", False),
    ]
    store.add(
        NewsItem(
            id=f"seed:{i}", source=s, handle=s, text=t, url="#", category=c, ts=now - i * 60, hot=h
        )
        for i, (c, s, t, h) in enumerate(samples)
    )
