"""
Entry point for cPanel / GoDaddy "Setup Python App" (Phusion Passenger).

cPanel generates a stub with this name; replace its contents with this file.
It loads .env (if present) and exposes the Flask app as `application`.
"""
import os
import sys

BASE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE)
os.chdir(BASE)

# Passenger doesn't read .env automatically; do it here so tokens work.
try:
    from dotenv import load_dotenv
    load_dotenv(os.path.join(BASE, ".env"))
except ImportError:
    pass

from app import app as application  # noqa: E402
