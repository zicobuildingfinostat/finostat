"""
Finostat — Flask web app
========================

Run locally:
    pip install -r requirements.txt
    python app.py
Then open http://127.0.0.1:5000

Where to plug in real data:
    - get_quotes()  -> index/commodity ticker across the top of the page
    - get_sheet()   -> the live butterfly sheet in the hero terminal
Both currently return simulated numbers so the site works out of the box.
Replace their bodies with calls to your broker / NSE data feed and nothing
else needs to change — the JavaScript polls /api/quotes and /api/sheet.
"""

from __future__ import annotations

import json
import logging
import random
from datetime import datetime
from zoneinfo import ZoneInfo

try:
    from dotenv import load_dotenv
    load_dotenv()  # must run before news/upstox read os.environ
except ImportError:
    pass

from flask import Flask, Response, jsonify, render_template, request

import news  # noqa: E402
import upstox  # noqa: E402

app = Flask(__name__)
logging.basicConfig(level=logging.INFO)

IST = ZoneInfo("Asia/Kolkata")

# ---------------------------------------------------------------------------
# Simulated market state (replace with a real feed)
# ---------------------------------------------------------------------------

_QUOTES: dict[str, list[float]] = {
    # symbol: [price, day_change_pct]
    "NIFTY 50": [24812.35, 0.42],
    "BANKNIFTY": [54187.60, -0.18],
    "SENSEX": [81406.12, 0.37],
    "FINNIFTY": [26014.80, 0.21],
    "INDIA VIX": [12.84, -3.10],
    "GIFT NIFTY": [24856.00, 0.16],
    "GOLD": [102440.0, 0.55],
    "CRUDE": [6842.0, -1.02],
    "USDINR": [87.42, 0.06],
}

# strike, CE, PE, butterfly (1:2:1), net
_SHEET: list[list[float]] = [
    [24500, 318.0, 27.4, 52.1, -14.2],
    [24550, 274.1, 33.6, 44.8, -11.7],
    [24600, 232.4, 41.2, 38.6, -9.4],
    [24650, 196.8, 52.1, 33.1, -7.2],
    [24700, 164.0, 66.5, 29.8, -5.1],
    [24750, 134.2, 84.9, 27.4, -2.6],
    [24800, 108.6, 106.3, 26.9, 0.0],
    [24850, 86.1, 132.4, 28.2, 2.4],
    [24900, 67.3, 163.0, 31.5, 5.8],
    [24950, 51.9, 197.6, 35.7, 8.9],
    [25000, 39.4, 235.2, 41.0, 11.6],
    [25050, 29.8, 275.9, 47.3, 14.1],
]

_MINI: list[list[float]] = [
    [54000, 11.4, -8.2],
    [54100, 14.8, -6.1],
    [54200, 9.7, -9.9],
    [54300, 7.3, -12.4],
]


def _jitter(value: float, amount: float, floor: float = 0.5) -> float:
    return round(max(floor, value + random.uniform(-amount, amount)), 2)


def get_quotes() -> list[dict]:
    """Ticker-tape quotes: live from Upstox when a token is set, else simulated."""
    if upstox.enabled():
        try:
            live = upstox.quotes()
            if live:
                return live
        except Exception as exc:
            logging.getLogger("finostat").warning("Upstox quotes failed, using sim: %s", exc)
    out = []
    for symbol, (price, change) in _QUOTES.items():
        # nudge the simulated numbers so the tape feels alive
        price = _jitter(price, price * 0.0004, floor=0.01)
        change = round(change + random.uniform(-0.02, 0.02), 2)
        _QUOTES[symbol] = [price, change]
        out.append({"symbol": symbol, "price": price, "change": change})
    return out


def get_sheet() -> dict:
    """Butterfly sheet: live Upstox option chain when a token is set, else simulated."""
    if upstox.enabled():
        try:
            return upstox.butterfly_sheet()
        except Exception as exc:
            logging.getLogger("finostat").warning("Upstox chain failed, using sim: %s", exc)
    expiry = "28AUG26"
    for row in _SHEET:
        for j in (1, 2):  # CE, PE
            row[j] = _jitter(row[j], 1.8)
        row[3] = _jitter(row[3], 0.8)          # butterfly value
        row[4] = round(row[4] + random.uniform(-0.3, 0.3), 1)  # net
    return {"symbol": f"NIFTY · {expiry}", "ratio": "1:2:1", "rows": _SHEET}


def market_is_open(now: datetime) -> bool:
    minutes = now.hour * 60 + now.minute
    return now.weekday() < 5 and 555 <= minutes <= 930  # 09:15–15:30 IST


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------

@app.route("/")
def index():
    now = datetime.now(IST)
    sheet = get_sheet()
    return render_template(
        "index.html",
        quotes=get_quotes(),
        sheet=sheet,
        now=now.strftime("%H:%M:%S"),
        market_open=market_is_open(now),
        page_data={"symbol": sheet["symbol"], "sheet": sheet["rows"], "mini": _MINI, "atm": sheet.get("atm")},
        news_items=news.store.latest(limit=30),
        news_via_x=bool(news.X_BEARER_TOKEN),
        data_source="upstox" if upstox.enabled() else "simulated",
    )


@app.route("/api/quotes")
def api_quotes():
    return jsonify(get_quotes())


@app.route("/api/sheet")
def api_sheet():
    return jsonify(get_sheet())


@app.route("/api/news")
def api_news():
    """Latest headlines. ?category=FIN|GEO, ?limit=N"""
    cat = request.args.get("category")
    limit = min(int(request.args.get("limit", 40)), 100)
    return jsonify(news.store.latest(cat, limit))


@app.route("/api/news/stream")
def api_news_stream():
    """Server-Sent Events: pushes new headlines to the browser as they arrive."""
    q = news.store.subscribe()

    def gen():
        try:
            yield "retry: 5000\n\n"
            while True:
                try:
                    payload = q.get(timeout=25)
                    yield f"event: news\ndata: {payload}\n\n"
                except Exception:
                    yield ": keep-alive\n\n"  # comment line keeps proxies from closing idle streams
        finally:
            news.store.unsubscribe(q)

    return Response(
        gen(),
        mimetype="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


@app.route("/api/status")
def api_status():
    now = datetime.now(IST)
    return jsonify({
        "time": now.strftime("%H:%M:%S"),
        "market_open": market_is_open(now),
        "data_source": "upstox" if upstox.enabled() else "simulated",
        "news_source": "x+rss" if news.X_BEARER_TOKEN else "rss",
    })


# Start the news poller when the app is imported (works under gunicorn too).
news.seed_sample()
news.start_background()

if __name__ == "__main__":
    # use_reloader=False so the background thread isn't started twice
    app.run(debug=True, use_reloader=False, threaded=True)
