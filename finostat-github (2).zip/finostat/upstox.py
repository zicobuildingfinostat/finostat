"""
Upstox market-data adapter
==========================

Feeds the ticker and the hero butterfly sheet with real NSE/BSE data via the
Upstox API v2. Needs UPSTOX_ACCESS_TOKEN in the environment (an "extended"
token from a Plus plan works for these read-only endpoints).

Endpoints used (all GET, Bearer auth):
  /v2/market-quote/quotes      index & commodity LTPs
  /v2/option/contract          list expiries for an underlying
  /v2/option/chain             CE/PE LTPs per strike for one expiry

Responses are cached for a second or two so a page full of visitors doesn't
hammer the API.
"""

from __future__ import annotations

import logging
import os
import time
from datetime import date

import requests

log = logging.getLogger("finostat.upstox")

TOKEN = os.environ.get("UPSTOX_ACCESS_TOKEN", "").strip()
BASE = "https://api.upstox.com/v2"

# Ticker symbols -> Upstox instrument keys
TICKER: dict[str, str] = {
    "NIFTY 50": "NSE_INDEX|Nifty 50",
    "BANKNIFTY": "NSE_INDEX|Nifty Bank",
    "SENSEX": "BSE_INDEX|SENSEX",
    "FINNIFTY": "NSE_INDEX|Nifty Fin Service",
    "INDIA VIX": "NSE_INDEX|India VIX",
    "MIDCPNIFTY": "NSE_INDEX|NIFTY MID SELECT",
}

SHEET_UNDERLYING = "NSE_INDEX|Nifty 50"
SHEET_LABEL = "NIFTY"
STRIKE_STEP = 50          # Nifty strike interval
ROWS_EACH_SIDE = 4        # strikes shown above/below ATM


def enabled() -> bool:
    return bool(TOKEN)


def _get(path: str, **params) -> dict:
    r = requests.get(
        f"{BASE}{path}",
        params=params,
        headers={"Authorization": f"Bearer {TOKEN}", "Accept": "application/json"},
        timeout=8,
    )
    r.raise_for_status()
    body = r.json()
    if body.get("status") != "success":
        raise RuntimeError(f"Upstox error: {body}")
    return body["data"]


# ---------------------------------------------------------------------------
# tiny TTL cache
# ---------------------------------------------------------------------------

_cache: dict[str, tuple[float, object]] = {}


def _cached(key: str, ttl: float, fn):
    now = time.time()
    hit = _cache.get(key)
    if hit and now - hit[0] < ttl:
        return hit[1]
    val = fn()
    _cache[key] = (now, val)
    return val


# ---------------------------------------------------------------------------
# Quotes
# ---------------------------------------------------------------------------

def quotes() -> list[dict]:
    def fetch():
        data = _get("/market-quote/quotes", instrument_key=",".join(TICKER.values()))
        out = []
        for label, ikey in TICKER.items():
            # Upstox returns keys as "NSE_INDEX:Nifty 50" (colon, not pipe)
            q = data.get(ikey.replace("|", ":"))
            if not q:
                continue
            ltp = float(q.get("last_price") or 0)
            chg = float(q.get("net_change") or 0)
            prev = ltp - chg
            pct = round(chg / prev * 100, 2) if prev else 0.0
            out.append({"symbol": label, "price": round(ltp, 2), "change": pct})
        return out

    return _cached("quotes", 2.0, fetch)


# ---------------------------------------------------------------------------
# Option chain -> butterfly sheet
# ---------------------------------------------------------------------------

def nearest_expiry(instrument_key: str = SHEET_UNDERLYING) -> str:
    def fetch():
        contracts = _get("/option/contract", instrument_key=instrument_key)
        today = date.today().isoformat()
        exps = sorted({c["expiry"] for c in contracts if c.get("expiry", "") >= today})
        if not exps:
            raise RuntimeError("no upcoming expiries")
        return exps[0]

    return _cached(f"expiry:{instrument_key}", 3600, fetch)


def butterfly_sheet() -> dict:
    """
    Returns {"symbol": "NIFTY · 28AUG26", "ratio": "1:2:1", "rows": [...]}
    rows: [strike, CE_ltp, PE_ltp, butterfly_1_2_1, net]
      butterfly = CE(K-step) - 2*CE(K) + CE(K+step)
      net       = (CE - PE) - (spot - K)   synthetic-forward mispricing
    """
    def fetch():
        expiry = nearest_expiry()
        chain = _get("/option/chain", instrument_key=SHEET_UNDERLYING, expiry_date=expiry)
        by_strike: dict[float, tuple[float, float]] = {}
        spot = 0.0
        for row in chain:
            k = float(row["strike_price"])
            spot = float(row.get("underlying_spot_price") or spot)
            ce = float((row.get("call_options") or {}).get("market_data", {}).get("ltp") or 0)
            pe = float((row.get("put_options") or {}).get("market_data", {}).get("ltp") or 0)
            by_strike[k] = (ce, pe)

        atm = round(spot / STRIKE_STEP) * STRIKE_STEP
        rows = []
        for i in range(-ROWS_EACH_SIDE, ROWS_EACH_SIDE + 1):
            k = atm + i * STRIKE_STEP
            ce, pe = by_strike.get(k, (0.0, 0.0))
            lo = by_strike.get(k - STRIKE_STEP, (0.0, 0.0))[0]
            hi = by_strike.get(k + STRIKE_STEP, (0.0, 0.0))[0]
            bfly = lo - 2 * ce + hi if (lo and hi and ce) else 0.0
            net = (ce - pe) - (spot - k) if (ce and pe) else 0.0
            rows.append([int(k), round(ce, 1), round(pe, 1), round(bfly, 1), round(net, 1)])

        d = date.fromisoformat(expiry)
        label = f"{SHEET_LABEL} · {d.strftime('%d%b%y').upper()}"
        return {"symbol": label, "ratio": "1:2:1", "rows": rows, "spot": spot, "atm": atm}

    return _cached("sheet", 1.0, fetch)
