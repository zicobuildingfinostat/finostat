# Finostat website (Flask)

## Run locally
```bash
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python app.py
```
Open http://127.0.0.1:5000

## Project layout
```
app.py                  Flask app, routes, and the two data functions to replace
templates/index.html    Page markup (Jinja2)
static/css/style.css    Theme (colours are CSS variables at the top of the file)
static/js/main.js       Ticker + sheet polling, animations
static/img/             Logo
```

## Live data
Set `UPSTOX_ACCESS_TOKEN` in `.env` and the ticker + butterfly sheet switch to live Upstox data automatically (see `upstox.py`). Without it, `get_quotes()` and `get_sheet()` in `app.py` return simulated numbers. They return plain Python
lists/dicts; the front end polls `/api/quotes` every 15s and `/api/sheet`
about once per second.

## Deploy
Any host that runs Python works (Render, Railway, PythonAnywhere, a VPS):
```bash
gunicorn app:app --bind 0.0.0.0:8000
```
Point finostat.com at the host and switch off the GoDaddy site builder page.

## Deploy on GoDaddy cPanel hosting (Setup Python App)
Requires a GoDaddy *Web Hosting* plan (Linux, cPanel). The Website Builder plan cannot run Python.
1. cPanel -> File Manager -> upload the zip into `/home/<user>/finostat` and extract it.
2. cPanel -> Setup Python App -> Create Application:
   Python 3.10+, Application root `finostat`, Application URL `finostat.com`,
   Application startup file `passenger_wsgi.py`, Entry point `application`.
3. Under Configuration files add `requirements.txt` and click Run Pip Install.
4. Environment variables: add `UPSTOX_ACCESS_TOKEN` (and optionally `X_BEARER_TOKEN`).
   Alternatively create `.env` next to `passenger_wsgi.py` (never upload it to GitHub).
5. Click Restart. Visit https://finostat.com and check /api/status.
Note: shared hosting recycles idle processes; the news poller restarts on the next visit.
