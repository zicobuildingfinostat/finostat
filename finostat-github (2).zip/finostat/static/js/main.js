(function(){
  const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const fmt = (n,d=2)=>n.toLocaleString('en-IN',{minimumFractionDigits:d,maximumFractionDigits:d});

  /* ---- ticker tape ---- */
  const t=document.getElementById('tape');
  const renderTape=q=>{const b=q.map(x=>`<span><b>${x.symbol}</b>${fmt(x.price)}<em class="${x.change>=0?'up':'down'}">${x.change>=0?'▲':'▼'} ${Math.abs(x.change).toFixed(2)}%</em></span>`).join('');t.innerHTML=b+b;};
  const loadTape=()=>fetch('/api/quotes').then(r=>r.json()).then(renderTape).catch(()=>{});
  loadTape(); setInterval(loadTape,15000);

  /* ---- hero butterfly sheet ---- */
  const rows=(window.FINO&&window.FINO.sheet)||[];
  const tb=document.getElementById('hero-rows');
  document.getElementById('hero-sym').textContent=(window.FINO&&window.FINO.symbol)||'NIFTY';
  const atmI=(window.FINO&&window.FINO.atm)?rows.findIndex(r=>r[0]===window.FINO.atm):Math.floor(rows.length/2);
  tb.innerHTML=rows.map((r,i)=>`<tr${i===atmI?' class="atm"':''}><td>${r[0]}</td>${r.slice(1).map((v,j)=>`<td data-r="${i}" data-c="${j}" class="${j===3?(v>0?'up':v<0?'down':''):''}">${v.toFixed(1)}</td>`).join('')}</tr>`).join('');
  const cells=[...tb.querySelectorAll('td[data-r]')];
  function applySheet(fresh){
    fresh.forEach((r,i)=>{
      if(!rows[i]) return;
      for(let j=0;j<4;j++){
        const nv=r[j+1], ov=rows[i][j+1];
        if(nv===ov) continue;
        const cell=cells.find(c=>c.dataset.r==i&&c.dataset.c==j);
        if(!cell) continue;
        rows[i][j+1]=nv; cell.textContent=nv.toFixed(1);
        if(j===3){cell.classList.toggle('up',nv>0);cell.classList.toggle('down',nv<0);}
        if(reduce) continue;
        cell.classList.remove('flash-up','flash-down'); void cell.offsetWidth;
        cell.classList.add(nv>=ov?'flash-up':'flash-down');
        setTimeout(()=>cell.classList.remove('flash-up','flash-down'),500);
      }
    });
  }
  const pollSheet=()=>fetch('/api/sheet').then(r=>r.json()).then(d=>applySheet(d.rows)).catch(()=>{});
  setInterval(pollSheet, reduce?5000:900);

  /* ---- typed command ---- */
  const cmds=['BFLY NIFTY 1:2:1','STRD BANKNIFTY','GEX NIFTY','CURV SENSEX','WIRE FIN'];
  const typed=document.getElementById('typed'); let ci=0,ch=0,del=false;
  function type(){
    const s=cmds[ci];
    typed.textContent=s.slice(0,ch);
    if(!del){ ch++; if(ch>s.length){del=true;return setTimeout(type,1800);} }
    else{ ch--; if(ch<0){del=false;ci=(ci+1)%cmds.length;ch=0;} }
    setTimeout(type,del?40:90);
  }
  if(reduce) typed.textContent=cmds[0]; else type();

  /* ---- mini sheet ---- */
  const mini=(window.FINO&&window.FINO.mini)||[[54000,11.4,-8.2],[54100,14.8,-6.1],[54200,9.7,-9.9],[54300,7.3,-12.4]];
  const mr=document.getElementById('mini-rows');
  const drawMini=()=>mr.innerHTML=mini.map(r=>`<tr><td>${r[0]}</td><td>${r[1].toFixed(1)}</td><td class="down">${r[2].toFixed(1)}</td><td class="${r[1]+r[2]>=0?'up':'down'}">${(r[1]+r[2]).toFixed(1)}</td></tr>`).join('');
  drawMini();
  if(!reduce) setInterval(()=>{const r=mini[Math.floor(Math.random()*mini.length)];r[1]=Math.max(1,r[1]+(Math.random()-.5)*1.2);r[2]=Math.min(-1,r[2]+(Math.random()-.5)*1.2);drawMini();},1300);

  /* ---- heatmap ---- */
  const heat=document.getElementById('heat'); let h='';
  for(let r=0;r<5;r++)for(let c=0;c<8;c++){
    const v=Math.abs(c-3.5)/3.5*0.7+r*0.06+Math.random()*0.15;
    const col=v>0.6?`rgba(255,110,200,${Math.min(1,v)})`:v>0.35?`rgba(245,200,66,${v+.2})`:`rgba(127,224,240,${.25+v})`;
    h+=`<i style="background:${col}"></i>`;
  }
  heat.innerHTML=h;

  /* ---- clock ---- */
  const clk=document.getElementById('clock'), mkt=document.getElementById('mkt');
  const setClock=()=>{const d=new Date().toLocaleTimeString('en-IN',{timeZone:'Asia/Kolkata',hour12:false});if(clk)clk.textContent=d+' IST';if(mkt){const o=isOpen();mkt.textContent='NSE '+(o?'OPEN':'CLOSED');mkt.classList.toggle('closed',!o);}};
  function isOpen(){const n=new Date(new Date().toLocaleString('en-US',{timeZone:'Asia/Kolkata'}));const m=n.getHours()*60+n.getMinutes();return n.getDay()>0&&n.getDay()<6&&m>=555&&m<=930;}
  setClock(); setInterval(setClock,1000);

  /* ---- news wire ---- */
  const list=document.getElementById('wire-list');
  if(list){
    const liveEl=document.getElementById('wire-live');
    let cat='';
    const hhmm=ts=>new Date(ts*1000).toLocaleTimeString('en-IN',{timeZone:'Asia/Kolkata',hour:'2-digit',minute:'2-digit',hour12:false});
    const stamp=()=>list.querySelectorAll('time[data-ts]').forEach(t=>t.textContent=hhmm(+t.dataset.ts));
    const filter=()=>list.querySelectorAll('li').forEach(li=>li.classList.toggle('hidden',!!cat&&li.dataset.cat!==cat));
    const esc=s=>s.replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
    const render=n=>{const li=document.createElement('li');li.dataset.cat=n.category;li.className=(n.hot?'hot ':'')+'new';
      li.innerHTML=`<time data-ts="${n.ts}">${hhmm(n.ts)}</time><div><a href="${esc(n.url)}" target="_blank" rel="noopener">${esc(n.text)}</a><div class="meta"><span class="tag ${n.category.toLowerCase()}">${n.category}</span><span>${esc(n.handle)}</span></div></div>`;
      return li;};
    const ingest=items=>{items.sort((a,b)=>b.ts-a.ts).reverse().forEach(n=>{if(list.querySelector(`a[href="${CSS.escape(n.url)}"]`))return;list.prepend(render(n));});
      while(list.children.length>120)list.lastElementChild.remove(); filter();};
    stamp(); setInterval(stamp,60000);
    document.querySelectorAll('.wire-tabs button').forEach(b=>b.addEventListener('click',()=>{document.querySelectorAll('.wire-tabs button').forEach(x=>x.classList.remove('on'));b.classList.add('on');cat=b.dataset.cat;filter();}));
    // Server-Sent Events for instant updates; fall back to polling if unsupported
    if('EventSource' in window){
      const es=new EventSource('/api/news/stream');
      es.addEventListener('news',e=>ingest(JSON.parse(e.data)));
      es.onopen=()=>liveEl.classList.remove('off'); es.onerror=()=>liveEl.classList.add('off');
    }else{
      setInterval(()=>fetch('/api/news?limit=30').then(r=>r.json()).then(ingest).catch(()=>{}),60000);
    }
  }

  /* ---- command bar ---- */
  const cmdForm=document.getElementById('cmd');
  if(cmdForm){
    const map={SHT:'#tools',SHEETS:'#tools',ANL:'#features',WIRE:'#wire',NEWS:'#wire',LRN:'#learn',LEARN:'#learn',LIV:'#tools',PLANS:'#plans',PLAN:'#plans',GEX:'#features',CURV:'#features',BKTS:'#features',RPLY:'#features',SURF:'#features',HOME:'#',HELP:'#tools'};
    cmdForm.addEventListener('submit',e=>{e.preventDefault();const v=cmdForm.querySelector('input').value.trim().toUpperCase().split(/\s+/)[0];const t=map[v];if(t){location.hash=t;cmdForm.querySelector('input').value='';}else{cmdForm.querySelector('input').value='';cmdForm.querySelector('input').placeholder='Unknown: '+v+'. Try SHT, ANL, WIRE, LRN';}});
    document.addEventListener('keydown',e=>{if(e.key==='/'&&document.activeElement.tagName!=='INPUT'){e.preventDefault();cmdForm.querySelector('input').focus();}});
  }

  /* ---- straddle sparkline (simulated intraday path) ---- */
  const line=document.getElementById('strd-line');
  if(line){
    const area=document.getElementById('strd-area'), last=document.getElementById('strd-last');
    const pts=[]; let v=270; for(let i=0;i<=60;i++){v+= (Math.random()-.52)*4; pts.push(v);}
    const draw=()=>{const min=Math.min(...pts),max=Math.max(...pts);const X=i=>i/(pts.length-1)*300, Y=p=>110-(p-min)/(max-min||1)*95;
      const d=pts.map((p,i)=>(i?'L':'M')+X(i).toFixed(1)+' '+Y(p).toFixed(1)).join(' ');line.setAttribute('d',d);area.setAttribute('d',d+' L300 115 L0 115 Z');last.textContent='₹'+pts[pts.length-1].toFixed(1);};
    draw();
    if(!reduce) setInterval(()=>{pts.push(pts[pts.length-1]+(Math.random()-.5)*3);pts.shift();draw();},1500);
  }

  /* ---- reveal ---- */
  const io=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){e.target.classList.add('in');io.unobserve(e.target);}}),{threshold:.12});
  document.querySelectorAll('.rv').forEach(el=>io.observe(el));
})();
